//
//  AmazonAdVersion.h
//  AmazonMobileAdsSDK
//
//  Copyright (c) 2016 Amazon.com. All rights reserved.
//
#ifndef AMAZON_AD_SDK_VERSION_NUMBER
#define AMAZON_AD_SDK_VERSION_NUMBER  "3.1.0"
#endif
