//
//  ADGAmazonAd.h
//  ADGAmazonAd
//
//  Created by yuki.kuroda on 2016/09/13.
//  Copyright © 2016年 Supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGAmazonAd.
FOUNDATION_EXPORT double ADGAmazonAdVersionNumber;

//! Project version string for ADGAmazonAd.
FOUNDATION_EXPORT const unsigned char ADGAmazonAdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import
// <ADGAmazonAd/PublicHeader.h>

@interface ADGAmazonAd

@end
