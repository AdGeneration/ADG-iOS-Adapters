//
//  AmazonMediation.h
//  ADGAmazonAd
//
//  Created by yuki.kuroda on 2016/09/13.
//  Copyright © 2016年 Supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>

@interface AmazonMediation : ADGNativeInterfaceChild <AmazonAdViewDelegate>

@end
