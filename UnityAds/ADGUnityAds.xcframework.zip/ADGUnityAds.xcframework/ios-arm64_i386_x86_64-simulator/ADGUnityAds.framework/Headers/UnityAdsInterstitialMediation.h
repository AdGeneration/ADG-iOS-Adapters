//
//  UnityAdsInterstitialMediation.h
//  ADGUnityAds
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>
#import "UnityAdsInterstitialMediationListener.h"

@interface UnityAdsInterstitialMediation : ADGNativeInterfaceChild<UnityAdsInterstitialMediationListenerDelegate>

@end
