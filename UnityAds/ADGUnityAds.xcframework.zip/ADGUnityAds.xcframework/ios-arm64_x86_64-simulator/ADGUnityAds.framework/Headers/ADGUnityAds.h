//
//  ADGUnityAds.h
//  ADGUnityAds
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGUnityAds.
FOUNDATION_EXPORT double ADGUnityAdsVersionNumber;

//! Project version string for ADGUnityAds.
FOUNDATION_EXPORT const unsigned char ADGUnityAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGUnityAds/PublicHeader.h>


