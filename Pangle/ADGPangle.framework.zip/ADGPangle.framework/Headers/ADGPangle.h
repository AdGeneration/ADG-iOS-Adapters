//
//  ADGPangle.h
//  ADGPangle
//
//  Created by james.kawashima on 2022/02/14.
//

#import <Foundation/Foundation.h>

//! Project version number for ADGPangle.
FOUNDATION_EXPORT double ADGPangleVersionNumber;

//! Project version string for ADGPangle.
FOUNDATION_EXPORT const unsigned char ADGPangleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGPangle/PublicHeader.h>


