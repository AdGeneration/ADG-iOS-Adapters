//
//  ADGAdMob.h
//  ADGAdMob
//
//  Copyright © 2023年 supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGAdMob.
FOUNDATION_EXPORT double ADGAdMobVersionNumber;

//! Project version string for ADGAdMob.
FOUNDATION_EXPORT const unsigned char ADGAdMobVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGAdMob/PublicHeader.h>


