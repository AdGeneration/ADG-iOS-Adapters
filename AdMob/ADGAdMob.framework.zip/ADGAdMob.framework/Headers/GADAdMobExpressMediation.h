//
//  GADAdMobExpressMediation.h
//  ADGAdMob
//
//  Copyright © 2016年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>

@interface GADAdMobExpressMediation : ADGNativeInterfaceChild

@end
