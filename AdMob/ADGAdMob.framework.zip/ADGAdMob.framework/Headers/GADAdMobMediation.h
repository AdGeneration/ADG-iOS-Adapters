//
//  GADAdMobMediation.h
//  ADGAdMob
//
//  Copyright © 2016年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>

@interface GADAdMobMediation : ADGNativeInterfaceChild

@end
