//
//  ADGMaio.h
//  ADGMaio
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGMaio.
FOUNDATION_EXPORT double ADGMaioVersionNumber;

//! Project version string for ADGMaio.
FOUNDATION_EXPORT const unsigned char ADGMaioVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGMaio/PublicHeader.h>


