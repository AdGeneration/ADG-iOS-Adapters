//
//  MaioInterstitialMediation.h
//  ADGMaio
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>
#import "MaioInterstitialMediationListener.h"

@interface MaioInterstitialMediation : ADGNativeInterfaceChild <MaioInterstitialMediationListenerDelegate>

@end
