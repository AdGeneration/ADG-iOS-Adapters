//
//  AppLovinInterstitialMediation.h
//  ADGAppLovin
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>

@interface AppLovinInterstitialMediation : ADGNativeInterfaceChild

@end
