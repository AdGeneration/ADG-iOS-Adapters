//
//  ADGAppLovin.h
//  ADGAppLovin
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGAppLovin.
FOUNDATION_EXPORT double ADGAppLovinVersionNumber;

//! Project version string for ADGAppLovin.
FOUNDATION_EXPORT const unsigned char ADGAppLovinVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGAppLovin/PublicHeader.h>


