//
//  FiveVideoRewardMediation.h
//  ADGFIVE
//
//  Copyright © 2020 Supership Inc. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>

@interface FiveVideoRewardMediation : ADGNativeInterfaceChild

@end
