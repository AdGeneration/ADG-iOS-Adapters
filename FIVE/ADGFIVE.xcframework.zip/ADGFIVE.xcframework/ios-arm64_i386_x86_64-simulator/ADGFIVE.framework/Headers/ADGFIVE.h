//
//  ADGFIVE.h
//  ADGFIVE
//
//  Copyright © 2020 Supership Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGFIVE.
FOUNDATION_EXPORT double ADGFIVEVersionNumber;

//! Project version string for ADGFIVE.
FOUNDATION_EXPORT const unsigned char ADGFIVEVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADGFIVE/PublicHeader.h>


