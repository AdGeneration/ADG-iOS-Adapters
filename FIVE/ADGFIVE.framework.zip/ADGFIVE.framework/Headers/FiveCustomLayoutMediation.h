//
//  FiveCustomLayoutMediation.h
//  ADGFIVE
//
//  Copyright © 2020 Supership Inc. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#import <UIKit/UIKit.h>

@interface FiveCustomLayoutMediation : ADGNativeInterfaceChild

@end
