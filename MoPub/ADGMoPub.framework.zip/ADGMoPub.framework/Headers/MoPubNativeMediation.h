//
//  MoPubNativeMediation.h
//  ADGMoPub
//
//  Copyright © 2018年 supership. All rights reserved.
//

#import <ADG/ADGNativeInterfaceChild.h>
#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#else
    #import "MoPub.h"
#endif

@interface MoPubNativeMediation : ADGNativeInterfaceChild
@property (nonatomic, strong) MPNativeAdRendererConfiguration *config;
- (void)startRequestProcess;

@end
