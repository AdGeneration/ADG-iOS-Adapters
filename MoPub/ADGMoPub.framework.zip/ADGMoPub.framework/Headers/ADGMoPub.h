//
//  ADGMoPub.h
//  ADGMoPub
//
//  Copyright © 2017年 supership. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADGMoPub.
FOUNDATION_EXPORT double ADGMoPubVersionNumber;

//! Project version string for ADGMoPub.
FOUNDATION_EXPORT const unsigned char ADGMoPubVersionString[];

#import <ADGMoPub/MoPubNativeMediation.h>

@interface ADGMoPub

@end
